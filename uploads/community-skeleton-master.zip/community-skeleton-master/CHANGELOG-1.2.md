CHANGELOG for 1.2.x
===================

This changelog references any relevant changes introduced in 1.2 minor versions.

* 1.2.x
    * PR #636: Fixed some language errors (rastiqdev)
