Security Policy
===============

⚠ PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, SEE BELOW.

If you have found a security issue in Uvdesk, please send the details to support@uvdesk.com and don't disclose it publicly until we can provide a fix for it.

Thanks!
